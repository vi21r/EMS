package com.example.ems

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
